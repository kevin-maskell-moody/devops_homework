magic_number=`cat /opt/install/license.txt`
echo "The answer to the meaning of life is $magic_number" > /opt/install/output.txt

